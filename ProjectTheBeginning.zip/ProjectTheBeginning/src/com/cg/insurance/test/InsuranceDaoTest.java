package com.cg.insurance.test;



import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;


import com.cg.insurance.bean.CreateAccount;
import com.cg.insurance.bean.DetailedReportBean;
import com.cg.insurance.bean.InsuranceFormBean;
import com.cg.insurance.bean.NewPolicySchemeBean;
import com.cg.insurance.bean.PolicyBean;
import com.cg.insurance.bean.PolicyDetailsBean;
import com.cg.insurance.bean.Question;
import com.cg.insurance.bean.ReportGeneration;
import com.cg.insurance.dao.InsuredDaoImpl;
import com.cg.insurance.exception.InsuranceException;

public class InsuranceDaoTest {

	static	InsuredDaoImpl insuredDaoImpl;
	static	CreateAccount acc;
	static	DetailedReportBean detailedreport;
	static	InsuranceFormBean form;
	static	NewPolicySchemeBean policy;
	static	PolicyBean bean;
	static	PolicyDetailsBean details;
	static	Question question;
	static	ReportGeneration report;
		@Test
		@Before
		public  void initialize()
		{
			System.out.println("in before class");
			insuredDaoImpl=new InsuredDaoImpl();
		 acc=new CreateAccount();
		 detailedreport=new DetailedReportBean();
		 form=new InsuranceFormBean();
		 policy=new NewPolicySchemeBean();
		 bean=new PolicyBean();
		 details=new PolicyDetailsBean();
		 question=new Question();
		 report=new ReportGeneration();
		
		
		}
		@Test
		 public void testLogin() throws SQLException, IOException, InsuranceException {
		//assertEquals("admin",insuredDaoImpl.login("Ramana","Ramana123"));
			//assertNotNull(insuredDaoImpl.login("Ramana","Ramana123"));
			//assertEquals("admin", insuredDaoImpl.login("Ramana","Ramana123").getRole_code());
		//	createAcc.setRole_code(role.admin);
			//assertEquals(role.admin,insuredDaoImpl.login("Ramana","Ramana123").getRole_code());
//		createAcc.setUsername("harshi");
//				createAcc.setPassword("Harshi123");
//			createAcc.setRole_code(role.agent);
		
			assertEquals("admin", insuredDaoImpl.login("harshitha","harshi123"));
		

			
		}

		@Test
		public	void testViewAllPolicies() throws Exception {
			assertNotNull(insuredDaoImpl.viewAllPolicies());
		}

		@Test
		public void testViewMyPolicies() throws Exception {
			assertNotNull(insuredDaoImpl.viewMyPolicies("harshitha"));
		}

		@Test
		public void testNewPolicy() throws Exception{
			assertNotNull(insuredDaoImpl.newPolicy(form));
			//assertEquals("inserted", insuredDaoImpl.newPolicy(form));
			
		}

		@Test
		public void testGetQuestions() throws SQLException, IOException, InsuranceException {
			assertNotNull(insuredDaoImpl.getQuestions("Business Auto"));
		}

		@Test
		public void testSetPremium() throws SQLException, IOException {
			assertTrue("Inserted",
					(insuredDaoImpl.setPremium(100)));

		
		}

		@Test
		public 	void testCreateAccount() {
		//	createAcc.setUsername("harshi");
			//createAcc.setPassword("Harshi123");
		//createAcc.setRole_code(role.agent);
			//assertNotNull(createAcc.getUsername());
		//assertEquals(createAcc,createAcc);
		//assertEquals(role.admin,insuredDaoImpl.login("Ramana","Ramana123").getRole_code());
		//assertEquals("x","x");

		}

		@Test
		public void testGenerateReport() throws SQLException, IOException {
			assertNotNull(insuredDaoImpl.generateReport("harshitha"));
		}
		

		@Test
		public void testGetDetailedReport() throws SQLException, IOException {
			//assertNotNull(insuredDaoImpl.getDetailedReport(101)); 
			assertEquals(detailedreport,detailedreport);
		}

		@Test
		public void testCreateNewScheme() {
			//assertNotNull(newPolicySchemeBean.getPol_ques_desc());
		}

	}

		




